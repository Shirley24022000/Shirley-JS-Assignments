// let number1 = 10;
// let number2 = 5;
// let sum = number1 + number2;
// // console.log("The sum of "+ number1 + "and" + number2 + "is : " + sum);

// document.getElementById("result").innerHTML = "The sum is : "
// + sum;

// let number1 = 10;
// let number2 = 5;
// let difference = number1 - number2;
// console.log("The difference of both numbers is : ", difference);

// document.getElementById("result").innerHTML = "The difference is : "
// + difference;


// let number1 = 10;
// let number2 = 5;
// let product = number1 * number2;
// console.log("The product of both numbers is : ", product);

// document.getElementById("result").innerHTML = "The product is : "
// + product;


// let number1 = 10;
// let number2 = 5;
// let quotient = number1 / number2;
// console.log("The sum of both numbers is : ", quotient);

// document.getElementById("result").innerHTML = "The quotient is : "
// + quotient;


let number1 = 10;
let number2 = 5;
let reminder = number1 % number2;
// console.log("The sum of both numbers is : ", reminder);

document.getElementById("result").innerHTML = "The reminder is : "
+ reminder;



