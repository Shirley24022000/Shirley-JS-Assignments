const birthyear = 2001;
console.log(birthyear);
birthyear = 2012;
document.getElementById("result").innerHTML = "The difference is : "
+ difference;
console.log(birthyear); // "This would throw a type error : Assignment to a constant variable"- Explanation- We can assign a value to a const variable but only during its declaration. After if we assign any value it will throw a type-error
