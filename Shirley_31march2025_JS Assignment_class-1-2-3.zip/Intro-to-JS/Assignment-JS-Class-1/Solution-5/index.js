if (true) {
      var a = 5;
      let b = 10;

}

console.log("a : ",a); // "a : 5" -Explanation- variable declared with var has function scope or global scope means if you declare and assign a var variable inside an if (true) block it will be accessible throughout the entire function and globally also even after the if block has finished executing. 

console.log("b : ",b); //  "b : This would also result in a reference error" - Explanation- variable declared with let has block scope this means they are only accessible within the if (true) block and it will not be accessible outside of that block.


