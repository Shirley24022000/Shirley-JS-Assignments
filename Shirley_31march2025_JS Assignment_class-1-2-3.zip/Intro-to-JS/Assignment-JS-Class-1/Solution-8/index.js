// function calculateSimpleInterest() {
//     // Get input values from the HTML elements
//     const principal = parseFloat(document.getElementById('principal').value);
//     const rate = parseFloat(document.getElementById('rate').value);
//     const time = parseFloat(document.getElementById('time').value);

    // Validate inputs
    // if (isNaN(principal) || isNaN(rate) || isNaN(time) || principal <= 0 || rate < 0 || time < 0) {
    //     document.getElementById('result').textContent = "Please enter valid positive numbers for all fields.";
    //     return;
    // }


    const principal = 10000;
    const rate = 5;
    const time = 5;

    // Calculate simple interest: SI = (P * R * T) / 100
    const simpleInterest = (principal * rate * time) / 100;

    // Display the result
    document.getElementById("output").textContent = `Simple Interest: ${simpleInterest.toFixed(2)}`;

