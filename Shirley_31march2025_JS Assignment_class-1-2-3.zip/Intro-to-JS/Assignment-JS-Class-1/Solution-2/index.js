// let str = "Hello"
// let outputelement = document.getElementById("output");
// outputelement.innerHTML = str;
// console.log(str);

// document.getElementById("result").innerHTML = "Hello -> typeof(stringg) ";

// let num = "42"
// let outputelement = document.getElementById("output");
// outputelement.innerHTML = num;
// console.log(num);

// let boolean = "true"
// let outputelement = document.getElementById("output");
// outputelement.innerHTML = boolean;
// console.log(boolean);

// let object = "null"
// let outputelement = document.getElementById("output");
// outputelement.innerHTML = object;
// console.log(object);

// let undefine = "undefined"
// let outputelement = document.getElementById("output");
// outputelement.innerHTML = undefine;
// console.log(undefine);

// let symbol = "symbol(>)"
// let outputelement = document.getElementById("output");
// outputelement.innerHTML = symbol;
// console.log(symbol);