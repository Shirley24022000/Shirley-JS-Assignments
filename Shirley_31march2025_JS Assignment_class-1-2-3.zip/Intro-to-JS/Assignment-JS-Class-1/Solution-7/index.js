//  declaration and initialization of three numbers
 let X = 5;
 let Y = 12;
 let Z = 43;

    // Calculate the average
    const average = (X + Y + Z) / 3;

    // Display the result
    document.getElementById("output").textContent =  `The average is: ${average.toFixed(2)}`;



