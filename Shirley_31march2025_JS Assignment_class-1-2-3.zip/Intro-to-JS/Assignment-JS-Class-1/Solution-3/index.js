let number1 = 10;
let number2 = 5;
let sum = number1 + number2;

// // console.log("The sum of "+ number1 + "and" + number2 + "is : " + sum);

document.getElementById("result").innerHTML = "The sum is : "
+ sum;