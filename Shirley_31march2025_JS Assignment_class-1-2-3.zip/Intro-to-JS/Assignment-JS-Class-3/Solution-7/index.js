function isPalindrome(str) {
  const cleanStr = str.toString().toLowerCase().replace(/[^a-z0-9]/g, '');
  const reversedStr = cleanStr.split('').reverse().join('');
  return cleanStr === reversedStr;
}

function checkPalindrome() {
  const inputElement = document.getElementById('input');
  const resultElement = document.getElementById('result');
  const inputValue = inputElement.value;

  if (inputValue) {
    if (isPalindrome(inputValue)) {
      resultElement.textContent = `"${inputValue}" is a palindrome.`;
    } else {
      resultElement.textContent = `"${inputValue}" is not a palindrome.`;
    }
  } else {
    resultElement.textContent = "Please enter a value.";
  }
}