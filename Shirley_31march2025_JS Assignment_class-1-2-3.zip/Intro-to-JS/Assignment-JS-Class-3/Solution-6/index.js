function sumDigits(number) {
      let sum = 0;
      const numStr = String(number);
      for (let i = 0; i < numStr.length; i++) {
        sum += parseInt(numStr[i]);
      }
      return sum;
    }

    function calculateSum() {
      const numInput = document.getElementById("number");
      const number = parseInt(numInput.value);
      const result = sumDigits(number);
      document.getElementById("result").textContent = "Sum of digits: " + result;
    }