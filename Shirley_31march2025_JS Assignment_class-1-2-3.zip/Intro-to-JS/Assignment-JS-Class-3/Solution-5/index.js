function factorial(n) {
      if (n === 0) {
        return 1;
      }
      return n * factorial(n - 1);
    }

    function calculateFactorial() {
      const num = parseInt(document.getElementById("numberInput").value);
      const resultElement = document.getElementById("result");

      if (isNaN(num) || num < 0) {
        resultElement.textContent = "Please enter a non-negative integer.";
      } else {
        const fact = factorial(num);
        resultElement.textContent = `Factorial of ${num} is ${fact}`;
      }
    }