function countWords(str) {
  if (str === null || str === "") {
    return 0;
  }
  // Remove leading/trailing whitespace and then split the string by spaces
  str = str.trim();
  const words = str.split(/\s+/);
  return words.length;
}


const textArea = document.getElementById('text-area');
const wordCountDisplay = document.getElementById('word-count');

textArea.addEventListener('input', () => {
    const text = textArea.value;
    const count = countWords(text);
    wordCountDisplay.textContent = `Word count: ${count}`;
});
