/**
 * Reverses a given string.
 * @param {string} str The string to be reversed.
 * @returns {string} The reversed string.
 */
function reverseString(str) {
    return str.split('').reverse().join('');
}

/**
 * Gets the input string, reverses it, and displays the result in the HTML.
 */
function displayReversedString() {
    const inputElement = document.getElementById('inputString');
    const outputElement = document.getElementById('reversedOutput');
    const originalString = inputElement.value;
    const reversed = reverseString(originalString);
    outputElement.textContent = reversed;
}
