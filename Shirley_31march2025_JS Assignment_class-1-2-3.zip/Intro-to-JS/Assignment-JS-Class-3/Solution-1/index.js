function generateTable() {
  const number = parseInt(document.getElementById("numberInput").value);
  const tableContainer = document.getElementById("tableContainer");

  if (isNaN(number)) {
    tableContainer.innerHTML = "<p>Please enter a valid number.</p>";
    return;
  }

  let tableHTML = "<table>";
  for (let i = 1; i <= 10; i++) {
    tableHTML += `
      <tr>
        <td>${number} x ${i} =</td>
        <td>${number * i}</td>
      </tr>
    `;
  }
  tableHTML += "</table>";

  tableContainer.innerHTML = tableHTML;
}