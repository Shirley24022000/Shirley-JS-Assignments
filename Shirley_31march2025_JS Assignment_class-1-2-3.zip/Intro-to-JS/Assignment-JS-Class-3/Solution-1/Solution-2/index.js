function sumEvenNumbers() {
      let sum = 0;
      for (let i = 2; i <= 20; i += 2) {
        sum += i;
      }
      return sum;
    }

    const result = sumEvenNumbers();
    document.getElementById("result").innerText = "The sum of even numbers from 1 to 20 is: " + result;