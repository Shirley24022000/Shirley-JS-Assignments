
// Msg way in JS (mostly you guys are going to use console.log only!)
// console.log('Hello world!');
// console.error("ATM card PIN is incorrect!");
// console.warn("Hi try to use your card again!");
// console.info("Hi this is an importnat msg for you! that CodeKerdos is here to help you with everything!");



// var (old appraoch), let and const





var a = 10;
// console.log(a);
// Redeclare
var a = "Mango";
// console.log(a);
// Reassign
a = 33;
// console.log(a);



if(true){
    var age = 25;
}

// console.log(age);


// var GrandParent = 10;

// {
//     var Parent = 5;
//     console.log(GrandParent,"Comes from Grandparent");
//     {
//         var child = 5;
//         console.log(Parent,"Comes from Parent");
//     }
// }
// Parent = 66;
// console.log(Parent, "Property comes from Parent to Grandparent");



// let  Example

// global scope
// let GrandParent = 15;

// Redeclare is not allow in same scope
// Reassign with in the same scope;


// {
//     let GrandParent2 = 30;
//     let Parent = 15;
//     console.log(GrandParent,"Comes from Grandparent it is in global scope");
//      GrandParent2 = 50;
//     {
//         let child1 = 7.5;
//         let child2 = 7.5;
//         console.log(Parent,"Comes from Parent, come from block scope of parent ");
//         console.log(child1,"Comes from Parent, for child 1");
//         console.log(child2,"Comes from Parent, for child 2");
       
//         console.log(GrandParent2,"Comes from GrandParent, for child 3");


//     }
// }
// console.log(Parent, "Property comes from Parent to Grandparent");






{
    // Code by Rohan
    // let amit = 25;








// {
//     let count = 0;
//     console.log("Before increment",count);

//     if(true){
//         count++;
//     }
//     console.log("After increment",count);


// }


// const Item = 100;
// // Reassign not allowed
// // Item = 200;
// console.log(Item);

// // Redeclare not allowed
//  const Item = 300;
//     console.log(Item);


// Declare
// let a = 10;
// console.log(a,"Declare");
// Reassign 
// a = 30;
// console.log(a,"Reassign");
// Redeclare
// let a = 30;


// JS  two type of Data types 

// primitives non-primitives

// primitives ==> str, num, boolean, null, and undefined symbol(advance)

// let str = "JavaScript";
// let num = 100;
// let isOnline = true;
// let empty = null;
// let x;
// let sym = Symbol('id');

// console.log(typeof(str));
// console.log(typeof(num));
// console.log(typeof(isOnline));
// console.log(typeof(empty));
// console.log(typeof(x));
// console.log(typeof(sym));



// Operators

// Arithmetic ==> +,-,*,/,%
// Assignment ==> =, +=, -=, *=
// Comparison ==> ==, ===, != , >,<,>=
// Logical ==> &&, ||, !
// String Concatenation ==> +



// let a = 10;
// let b = 5;
// console.log(a+b);
// console.log(a == 10);

// console.log(a>b && b < 10);


// console.log("hi"+"Hello");




// Code by Vikas
    // let amit = 30;
    
}


// 05/06/2025 scope --> (Variable ka area jahan tak wo accessible hai!)

// Global, local scope


// Global --> You can access variable anywhere!
// Local scope --> You can access within the block or a function!
// lexical scope --> inner function can access the attributes and parameters of it's outer function (parent fun)!

// let x = 10; //global scope

// function test(c){
//     let y = 20; // local scope
//     console.log(x);
//     console.log(y);
//     function test2(){
//         console.log("This is in the test2 fun: ",y);
//         console.log("This is parameter value from  outer Fun and this is we called lexical scope: ",c);
//         console.log("This is global variable :  ",x);
//         function test3(){
//             console.log(y, " Value comes from outer --> outer fun!");
//         }
//         test3();

//     }
//     test2();
// }

// test(3);
// console.log(x);

// console.log(y);// accessible nahi h local scope or function scope!




// Control flow : conditions and loops

// conditions if, else if, else

// if,else condition
// let marks = 74;

// if(marks >= 90){
//     console.log("Grade A");
// }else if(marks >= 75){
//     console.log("Grade B");
// }else{
//     console.log("Grade C");
// }


// Switch case

// let day = "Friday";

// switch(day){
//     case "Monday": 
//     console.log("Start of the week");
//     break;
//     case "Friday":
//         console.log("Weekend Coming!");
//         break;
//     default:
//         console.log("Midweek Day");
// }

// Loops

// for loop

// for(let i = 1; i<=5; i++){
//     console.log("Number: ", i);
// }

// while loop


// let i = 1;
// while(i <= 3){
//     console.log("While loop : ",i);
//     i++;
// }



// do while 

// let i = 1;
// do{
//     console.log("Do while : ", i);
//     i++;
// }while(i <= 2);


// Strings 

// let str = "HelloJavaScript Class in CodeKerdos!";

// console.log(str);
// console.log(str.length); // 37
// console.log(str.toUpperCase()); //HELLO JAVASCRIPT CLASS IN CODEKERDOS!
// console.log(str.toLowerCase()); //hello javascript class in codekerdos!
// console.log(str.includes("Java")); // true

// if(str.includes("Java")){
//     console.log("Yes it do contains Java!");
// }else{
//      console.log("Yes it does not!");
// }

// console.log(str.replace("Class","Session"));
// console.log(str.slice(0,5));



// Numbers

// let num = 123.456;

// console.log(num);
// console.log(num.toFixed(2));// 123.45
// console.log(typeof(num));
// console.log(num.toString());// num converted to String
// console.log(typeof(num.toString()));
// console.log("45");
// console.log(typeof("45"));
// console.log(Number("45"));// 45 (string to number)
// console.log(typeof(Number("45")));
// console.log(parseInt("50.5"));// 50 (string to number) 
// console.log(parseFloat("50.5")); //50.5 (string to number)







// let valA = "5"; // string
// let valB = 5; // number

// //== check only value BUT === value and it's type

// if(valA === valB){
//    console.log("true");
// }else{
//     console.log("false");
// }



// Null and Undefined

// let h = 100;
// let i;

// console.log(h + i);

// let x = 10;
// let y = null;
// console.log(x + y);


// Non-primitives (array, objects);


// let items = ["mango",23, null, "banana", "delhi", 445.78];

// console.log(items);
// console.log(items[5]);
// console.log(items.length);


// Objects (real world models)

let student = {
    name:"Rohan",
    Place: "UK",
    age:33,
    greet : function(){
        console.log("Hi this is Rohan, How are you today!");
    }
}

console.log(student);
console.log(student.name);
console.log(student.Place);
console.log(student.age);
console.log(student.greet());





