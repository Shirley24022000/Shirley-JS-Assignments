function calculateSum() {
    const numberInput = document.getElementById('numberInput');
    const resultParagraph = document.getElementById('result');
    const inputNumber = numberInput.value;

    // Validate input to ensure it's a valid number
    // if (isNaN(inputNumber) || inputNumber.trim() === '') {
    //     resultParagraph.textContent = 'Please enter a valid number.';
    //     return;
    // }

    let sum = 0;
    // Iterate through each character of the number string
    for (let i = 0; i < inputNumber.length; i++) {
        // Convert each character to a number and add to sum
        sum += parseInt(inputNumber[i]);
    }

    resultParagraph.textContent = `The sum of digits is: ${sum}`;
}