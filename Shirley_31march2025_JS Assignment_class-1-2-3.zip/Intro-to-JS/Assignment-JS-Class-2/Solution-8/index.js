// Define a string with leading and trailing whitespaces
const myString = "   Hello, World!   ";

// Function to remove leading and trailing whitespaces
function trimString(str) {
    return str.trim(); // The trim() method removes leading and trailing whitespace
}

// Get the HTML elements to display the strings
const originalStringElement = document.getElementById('originalString');
const trimmedStringElement = document.getElementById('trimmedString');

// Display the original string
originalStringElement.textContent = `"${myString}"`;

// Get the trimmed string
const trimmedResult = trimString(myString);

// Display the trimmed string
trimmedStringElement.textContent = `"${trimmedResult}"`;