function replaceString() {
      const s1 = document.getElementById("s1").value;
      const s2 = document.getElementById("s2").value;
      const s3 = document.getElementById("s3").value;

      const index = s1.indexOf(s2);
      let resultString = "";

      if (index !== -1) {
        resultString = s1.slice(0, index) + s3 + s1.slice(index + s2.length);
      } else {
          resultString = s1; // If s2 is not found, return the original string.
      }

      document.getElementById("result").innerText = "Result: " + resultString;
    }