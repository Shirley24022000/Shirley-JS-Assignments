function checkNumber() {
      const num = document.getElementById("number").value;
      const number = parseInt(num);
      let resultText = document.getElementById("result");

      if (isNaN(number)) {
        resultText.textContent = "Invalid input. Please enter a valid number.";
      } else if (number > 0) {
        resultText.textContent = number + " is positive.";
      } else if (number < 0) {
        resultText.textContent = number + " is negative.";
      } else {
        resultText.textContent = number + " is zero.";
      }

    //   document.getElementById("result").textContent = resultText;
    }