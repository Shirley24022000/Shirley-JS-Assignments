function checkNumber() {
      const num = document.getElementById("number").value;
      const result = document.getElementById("result");

      if (num === "") {
        result.textContent = "Please enter a number.";
        return;
      }
      
      const parsedNum = parseInt(num);

      if (isNaN(parsedNum)) {
          result.textContent = "Invalid input. Please enter a number.";
          return;
      }


      if (parsedNum % 2 === 0) {
        result.textContent = parsedNum + " is even.";
      } else {
        result.textContent = parsedNum + " is odd.";
      }
    }