function convertToUppercase() {
    // Get the input string from the HTML element
    const inputElement = document.getElementById('inputString');
    const originalString = inputElement.value;

    // Convert the string to uppercase
    const uppercaseString = originalString.toUpperCase();

    // Display the uppercase string in the HTML
    const outputElement = document.getElementById('outputString');
    outputElement.textContent = uppercaseString;
}