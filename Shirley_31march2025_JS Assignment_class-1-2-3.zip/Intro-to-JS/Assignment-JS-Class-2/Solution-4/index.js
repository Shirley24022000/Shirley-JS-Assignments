// Define the floating-point number
const originalFloat = 123.45678;

// Function to round up to 2 decimal places
function roundUpToTwoDecimals(num) {
    // Multiply by 100, use Math.ceil to round up, then divide by 100
    return Math.ceil(num * 100) / 100;
}

// Get references to the HTML elements
const originalNumberSpan = document.getElementById('originalNumber');
const roundedNumberSpan = document.getElementById('roundedNumber');

// Display the original number
originalNumberSpan.textContent = originalFloat;

// Calculate the rounded up number
const roundedUp = roundUpToTwoDecimals(originalFloat);

// Display the rounded up number
roundedNumberSpan.textContent = roundedUp.toFixed(2); // Use toFixed(2) to ensure two decimal places are displayed, even if trailing zeros are needed
