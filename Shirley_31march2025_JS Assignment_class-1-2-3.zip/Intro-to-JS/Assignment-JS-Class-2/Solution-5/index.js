// Define the string
const myString = "Hello, JavaScript!";

// Get the length of the string
const stringLength = myString.length;

// Get the HTML element where the output will be displayed
const outputElement = document.getElementById("Output");

// Set the innerHTML of the element to display the string and its length
outputElement.innerHTML = `The string "${myString}" has a length of ${stringLength} characters.`;
