function checkEnding() {
    const sentence = document.getElementById('sentenceInput').value;
    const word = document.getElementById('wordInput').value;
    const resultParagraph = document.getElementById('result');

    if (sentence.trim() === "" || word.trim() === "") {
        resultParagraph.textContent = "Please enter both a sentence and a word.";
        resultParagraph.style.color = "orange";
        return;
    }

    if (sentence.endsWith(word)) {
        resultParagraph.textContent = `"${sentence}" ends with "${word}".`;
        resultParagraph.style.color = "green";
    } else {
        resultParagraph.textContent = `"${sentence}" does NOT end with "${word}".`;
        resultParagraph.style.color = "red";
    }
}