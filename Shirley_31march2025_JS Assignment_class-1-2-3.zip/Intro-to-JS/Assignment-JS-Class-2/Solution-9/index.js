function extractSubstring() {
    const sentence = document.getElementById('sentenceInput').value;
    const startIndex = parseInt(document.getElementById('startIndexInput').value);
    const endIndexInput = document.getElementById('endIndexInput').value;
    const resultParagraph = document.getElementById('result');

    if (!sentence) {
        resultParagraph.textContent = "Please enter a sentence.";
        return;
    }

    if (isNaN(startIndex)) {
        resultParagraph.textContent = "Please enter a valid start index.";
        return;
    }

    let substring;
    if (endIndexInput === "") {
        // If endIndex is not provided, extract to the end of the string
        substring = sentence.substring(startIndex);
    } else {
        const endIndex = parseInt(endIndexInput);
        if (isNaN(endIndex)) {
            resultParagraph.textContent = "Please enter a valid end index or leave it empty.";
            return;
        }
        substring = sentence.substring(startIndex, endIndex);
    }

    resultParagraph.textContent = `"${substring}"`;
}