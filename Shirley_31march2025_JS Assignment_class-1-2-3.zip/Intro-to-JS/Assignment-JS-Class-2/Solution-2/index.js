document.addEventListener('DOMContentLoaded', () => {
    const stringInput = document.getElementById('stringInput');
    const convertButton = document.getElementById('convertButton');
    const resultSpan = document.getElementById('result');

    convertButton.addEventListener('click', () => {
        const inputString = stringInput.value;
        let convertedNumber;

        // Attempt to convert the string to a number
        // Using Number() for general conversion (handles integers and floats)
        convertedNumber = Number(inputString);

        // You could also use:
        // parseInt(inputString) for integer conversion
        // parseFloat(inputString) for float conversion
        // +inputString (unary plus operator) for general conversion

        if (isNaN(convertedNumber)) {
            resultSpan.textContent = 'Characters are not allowed.';
            resultSpan.style.color = 'red';
        } else {
            resultSpan.textContent = convertedNumber;
            resultSpan.style.color = 'green';
        }
    });
});