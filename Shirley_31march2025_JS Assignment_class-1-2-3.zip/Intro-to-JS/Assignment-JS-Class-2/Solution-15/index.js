function findPosition() {
      const str = document.getElementById("stringInput").value;
      const character = document.getElementById("characterInput").value;
      const position = str.indexOf(character);
      const resultElement = document.getElementById("result");

      if (position === -1) {
        resultElement.textContent = "Character not found in the string.";
      } else {
        resultElement.textContent = `First occurrence of '${character}' is at position: ${position}`;
      }
    }