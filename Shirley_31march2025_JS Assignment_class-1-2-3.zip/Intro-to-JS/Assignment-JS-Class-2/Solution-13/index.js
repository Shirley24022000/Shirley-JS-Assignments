function checkString() {
      const sentence = document.getElementById("sentence").value;
      const word = document.getElementById("word").value;
      const resultDiv = document.getElementById("result");

      if (sentence.includes(word)) {
        resultDiv.textContent = `The word "${word}" is found in the sentence.`;
      } else {
        resultDiv.textContent = `The word "${word}" is not found in the sentence.`;
      }
    }