function displayCharacter() {
  const str = document.getElementById("stringInput").value;
  const n = parseInt(document.getElementById("positionInput").value);
  const resultElement = document.getElementById("result");

  if (isNaN(n) || n < 0 || n >= str.length) {
    resultElement.textContent = "Out of range";
  } else {
    resultElement.textContent = str.charAt(n);
  }
}