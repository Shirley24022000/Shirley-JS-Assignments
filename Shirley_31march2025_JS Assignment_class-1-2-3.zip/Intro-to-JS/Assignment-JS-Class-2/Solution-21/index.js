function isLeapYear(year) {
    // A year is a leap year if it is divisible by 4,
    // unless it is divisible by 100 but not by 400.
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}

function checkLeapYear() {
    const yearInput = document.getElementById('yearInput');
    const resultParagraph = document.getElementById('result');
    const year = parseInt(yearInput.value);

    if (isNaN(year)) {
        resultParagraph.textContent = "Please enter a valid number for the year.";
        resultParagraph.style.color = "red";
        return;
    }

    if (isLeapYear(year)) {
        resultParagraph.textContent = `${year} IS a leap year.`;
        resultParagraph.style.color = "green";
    } else {
        resultParagraph.textContent = `${year} IS NOT a leap year.`;
        resultParagraph.style.color = "red";
    }
}
